#include "GetMenuChoice.h"
#include "Tests.h"

int main() {
	test(false);
	fileSystemStart();
	

	return 0;
}